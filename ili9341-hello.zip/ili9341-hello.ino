#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <RotaryEncoder.h>
#include <math.h>
#include <GFButton.h>

// Pinos do Display SPI no Wokwi
#define TFT_CS   10
#define TFT_DC   9
#define TFT_RST  8

Adafruit_ILI9341 tela = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);
RotaryEncoder encoder(20, 21);
GFButton botao(A8);

int pot_motor = A10;
int angulo_pot = 0;
int ultimo_angulo_pot = -1;
int ultima_pos_encoder = -999;
unsigned long instante_anterior = 0;
int energia_max = 0;
int angulo_max = 0;
bool modo = false; // false é manual, true é automatico
int grafico[75] = {0}; // Vetor para armazenar os pontos do gráfico rolante
int pontos_coletados = 0;

void tickDoEncoder() {
  encoder.tick();
}

void mudar_modo() {
  if (modo == false) {
    tela.fillRect(42, 135, 70, 8, ILI9341_BLACK);
    tela.setCursor(42, 135);
    tela.setTextColor(ILI9341_WHITE);
    tela.setTextSize(1);
    tela.print("Automatico");
    modo = true;
  } else {
    tela.fillRect(42, 135, 70, 8, ILI9341_BLACK);
    tela.setCursor(42, 135);
    tela.setTextColor(ILI9341_WHITE);
    tela.setTextSize(1);
    tela.print("Manual");
    modo = false;
  }
}

void setup() {
  Serial.begin(9600);

  tela.begin();
  tela.setRotation(1);
  tela.fillScreen(ILI9341_BLACK);

  botao.setPressHandler(mudar_modo);

  int origem1 = digitalPinToInterrupt(20);
  attachInterrupt(origem1, tickDoEncoder, CHANGE);
  int origem2 = digitalPinToInterrupt(21);
  attachInterrupt(origem2, tickDoEncoder, CHANGE);

  tela.fillRect(0, 0, 320, 30, ILI9341_NAVY);
  tela.setCursor(20, 7);
  tela.setTextColor(ILI9341_WHITE);
  tela.setTextSize(2);
  tela.print("Ground Station Satelite");

  tela.drawRect(5, 36, 155, 95, ILI9341_WHITE);
  tela.drawRect(165, 36, 155, 95, ILI9341_WHITE);

  tela.drawLine(90, 83, 150, 83, ILI9341_CYAN);
  tela.drawLine(90, 83 + 1, 150, 83 + 1, ILI9341_CYAN);
  tela.fillCircle(120, 83, 3, ILI9341_WHITE);

  tela.setCursor(10, 135);
  tela.setTextColor(ILI9341_CYAN);
  tela.setTextSize(1);
  tela.print("Modo: ");

  tela.fillRect(42, 135, 70, 8, ILI9341_BLACK);
  tela.setCursor(42, 135);
  tela.setTextColor(ILI9341_WHITE);
  tela.setTextSize(1);
  tela.print("Manual");
  
  tela.setCursor(10, 145);
  tela.setTextColor(ILI9341_CYAN);
  tela.setTextSize(1);
  tela.print("Yaw: ");

  tela.setCursor(10, 155);
  tela.setTextColor(ILI9341_CYAN);
  tela.setTextSize(1);
  tela.print("Ang paineis: ");

  tela.setCursor(165, 138);
  tela.setTextColor(ILI9341_CYAN);
  tela.setTextSize(1);
  tela.print("Energia captada: ");

  tela.setCursor(165, 148);
  tela.setTextColor(ILI9341_CYAN);
  tela.setTextSize(1);
  tela.print("Energia maxima: ");

  tela.setCursor(80, 170);
  tela.setTextColor(ILI9341_WHITE);
  tela.setTextSize(1);
  tela.print("Mensagem traduzida:");

  tela.drawRect(10, 182, 300, 40, ILI9341_WHITE);
  tela.setCursor(20, 193);
  tela.setTextColor(ILI9341_CYAN);
  tela.setTextSize(2);
  tela.print("EU SOU UM SATELITE");
}

void loop() {
  botao.process();
  if (!modo) {
    int val_pot = analogRead(pot_motor); //modo manual
    angulo_pot = map(val_pot, 0, 1023, 0, 180);
  }
  int encoder_pos = encoder.getPosition();
  unsigned long instante_atual = millis();

  if (instante_atual > instante_anterior + 1000) {
    int energia_atual = 0;
    Serial.print(angulo_pot);
    Serial.print(";");
    Serial.println(modo ? 1 : 0);

    if (Serial.available() > 0) {
      String texto = Serial.readStringUntil('\n');
      texto.trim();
      int posPontoVirgula = texto.indexOf(';');
      
      if (posPontoVirgula != -1) {
        int angulo_recebido = texto.substring(0, posPontoVirgula).toInt();
        energia_atual = texto.substring(posPontoVirgula + 1).toInt();
        if (modo){
          angulo_pot = angulo_recebido; //modo automatico
        }
      }
    }

    if (pontos_coletados < 75) {
      grafico[pontos_coletados] = energia_atual;
      pontos_coletados++;
    } else {
      for (int i = 0; i < 74; i++) {
        grafico[i] = grafico[i + 1];
      }
      grafico[74] = energia_atual;
    }

    tela.fillRect(166, 37, 153, 93, ILI9341_BLACK);
    for (int i = 0; i < pontos_coletados - 1; i++) {
      tela.drawLine(166 + (i * 2), 130 - grafico[i], 166 + ((i + 1) * 2), 130 - grafico[i + 1], ILI9341_YELLOW);
    }

    tela.fillRect(265, 138, 50, 8, ILI9341_BLACK);
    tela.setCursor(265, 138);
    tela.setTextColor(ILI9341_WHITE);
    tela.setTextSize(1);
    tela.print(energia_atual);
    tela.print(" mW");

    if (energia_atual > energia_max) {
      energia_max = energia_atual;
      angulo_max = ultimo_angulo_pot;
      tela.fillRect(256, 148, 70, 8, ILI9341_BLACK);
      tela.setCursor(256, 148);
      tela.setTextColor(ILI9341_WHITE);
      tela.setTextSize(1);
      tela.print(energia_max);
      tela.print(" mW");
    }
    instante_anterior = instante_atual;
  }

  if (encoder_pos != ultima_pos_encoder) {
    tela.fillRect(40, 145, 70, 8, ILI9341_BLACK);
    tela.setCursor(40, 145);
    tela.setTextColor(ILI9341_WHITE);
    tela.setTextSize(1);
    tela.print(encoder_pos);
    tela.print(" deg");
    ultima_pos_encoder = encoder_pos;

    int cx = 45;
    int cy = 83;
    int raio = 25;
    float rad = (encoder_pos - 90) * PI / 180.0;
    int x1 = cx + (raio * cos(rad));
    int y1 = cy + (raio * sin(rad));
    tela.fillCircle(cx, cy, 27, ILI9341_WHITE);
    tela.drawLine(cx, cy, x1, y1, ILI9341_RED);
    tela.drawLine(cx, cy + 1, x1, y1 + 1, ILI9341_RED);
    tela.drawLine(cx, cy - 1, x1, y1 - 1, ILI9341_RED);
  }

  if (angulo_pot != ultimo_angulo_pot) {
    tela.fillRect(85, 155, 70, 8, ILI9341_BLACK);
    tela.setCursor(85, 155);
    tela.setTextColor(ILI9341_WHITE);
    tela.setTextSize(1);
    tela.print(angulo_pot);
    tela.print(" deg");
    ultimo_angulo_pot = angulo_pot;
    
    int cx = 120;
    int cy = 83;
    int raio = 30;
    float rad = angulo_pot * PI / 180.0;
    int x1 = cx - (raio * cos(rad));
    int y1 = cy + (raio * sin(rad));
    int x2 = cx + (raio * cos(rad));
    int y2 = cy - (raio * sin(rad));
    tela.fillCircle(cx, cy, 31, ILI9341_BLACK);
    tela.drawLine(x1, y1, x2, y2, ILI9341_CYAN);
    tela.drawLine(x1, y1 + 1, x2, y2 + 1, ILI9341_CYAN);
    tela.fillCircle(cx, cy, 3, ILI9341_WHITE);
  }
}